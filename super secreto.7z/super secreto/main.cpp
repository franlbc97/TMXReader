#include "MapData.h"
#include <string>
using namespace std;
int main(int argc, char* args[]) {
	 TMXReader::MapData * mapa("untitled.tmx");
	 delete mapa;
	return 0;
}